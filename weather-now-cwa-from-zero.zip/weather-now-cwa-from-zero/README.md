# 台灣氣象監測中心｜從零開始版

這是獨立新網站，不修改原有 Xuan Weather repository。

## 第一階段資料
- 中央氣象署 O-A0003-001：10 分鐘綜觀氣象觀測。
- 中央氣象署 F-D0047-093：全臺灣各鄉鎮市區預報資料。

## 部署
1. 建立新的 GitHub repository，例如 `weather-now-taiwan`。
2. 將本專案所有檔案推送至 `main`。
3. 在 repository 的 Settings → Secrets and variables → Actions 新增 `CWA_API_KEY`，值為你在中央氣象署開放資料平台申請的授權碼。
4. Settings → Pages → Build and deployment → Source 選擇 GitHub Actions。
5. Actions 執行 `Sync official CWA weather data and deploy`。

## 更新
- 工作流程每 10 分鐘執行一次，擷取觀測與鄉鎮預報，更新 JSON 並部署 Pages。
- API key 僅在 Actions runner 端使用，不會送到前端。
- 若官方 API 回傳失敗，工作流程會停止，不會以虛構數值替代真實資料。

## 注意
目前此版先完成官方測站觀測與鄉鎮預報的第一階段串接。GPS 會以實際官方測站座標計算最近站；預報選擇仍由縣市與鄉鎮下拉選單決定。雷達、衛星、風場、颱風、地震與警報會分階段新增。
